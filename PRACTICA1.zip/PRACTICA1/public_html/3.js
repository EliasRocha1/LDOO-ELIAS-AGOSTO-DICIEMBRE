function Mialerta() {
  confirm("Si estas de acuerdo con ir a otra pagina porfavor da click a cualquier link");
}

